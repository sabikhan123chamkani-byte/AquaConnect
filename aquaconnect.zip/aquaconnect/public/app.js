// AquaConnect Pakistan Frontend Application Client Logic
// Built using modern ES Modules and native DOM APIs

let currentUser = null;
let productsCache = [];
let ordersCache = [];
let currentTrackingOrderId = null;
let pollingIntervalId = null;

// --- DOM elements ---
const views = {
  landing: document.getElementById('view-landing'),
  login: document.getElementById('view-login'),
  register: document.getElementById('view-register'),
  customerDashboard: document.getElementById('view-customer-dashboard'),
  newOrder: document.getElementById('view-new-order'),
  trackOrder: document.getElementById('view-track-order'),
  orderHistory: document.getElementById('view-order-history'),
  supplierDashboard: document.getElementById('view-supplier-dashboard'),
  adminDashboard: document.getElementById('view-admin-dashboard'),
  profileSettings: document.getElementById('view-profile-settings'),
};

// --- Custom Router ---
function navigate(viewName, params = {}) {
  // Hide all views
  Object.values(views).forEach(view => {
    if (view) view.classList.add('hidden');
  });

  // Highlight navbar active link
  updateActiveNavLink(viewName);

  // Show target view
  const targetView = views[viewName];
  if (targetView) {
    targetView.classList.remove('hidden');
  }

  // View-specific loaders
  if (viewName === 'customerDashboard') {
    loadCustomerDashboard();
  } else if (viewName === 'newOrder') {
    loadBookingWizard();
  } else if (viewName === 'trackOrder') {
    if (params.orderId) {
      currentTrackingOrderId = params.orderId;
    }
    loadOrderTracker();
  } else if (viewName === 'orderHistory') {
    loadOrderHistory();
  } else if (viewName === 'supplierDashboard') {
    loadSupplierDashboard();
  } else if (viewName === 'adminDashboard') {
    loadAdminDashboard();
  } else if (viewName === 'profileSettings') {
    loadProfileSettings();
  }

  // Update browser history state
  const path = viewName === 'landing' ? '/' : `/${viewName}`;
  window.history.pushState({ view: viewName, params }, '', path);
}

// Handle browser Back/Forward navigation
window.addEventListener('popstate', (event) => {
  const state = event.state;
  if (state && state.view) {
    navigate(state.view, state.params);
  } else {
    navigate('landing');
  }
});

// Update active state in nav links
function updateActiveNavLink(viewName) {
  const links = document.querySelectorAll('.nav-item');
  links.forEach(link => {
    const linkPath = link.getAttribute('href');
    if (linkPath === `/${viewName}` || (viewName === 'landing' && linkPath === '/')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

// --- Dynamic Header Navigation ---
function renderHeader() {
  const mainNav = document.getElementById('main-nav');
  const globalHeader = document.getElementById('global-header');
  
  if (!currentUser) {
    globalHeader.classList.add('hidden');
    mainNav.innerHTML = '';
    return;
  }

  globalHeader.classList.remove('hidden');
  document.getElementById('header-user-name').textContent = currentUser.name;
  document.getElementById('header-user-role').textContent = currentUser.role === 'supplier' ? 'Water Supplier' : currentUser.role;
  document.getElementById('header-avatar-txt').textContent = currentUser.name.charAt(0).toUpperCase();

  let navHtml = '';
  if (currentUser.role === 'customer') {
    navHtml = `
      <a href="/customerDashboard" class="nav-item">Dashboard</a>
      <a href="/newOrder" class="nav-item">Order Water</a>
      <a href="/orderHistory" class="nav-item">Order History</a>
    `;
    // Show customer areas of user profile menu
    document.getElementById('profile-customer-area').classList.remove('hidden');
    document.getElementById('profile-supplier-area').classList.add('hidden');
  } else if (currentUser.role === 'supplier') {
    navHtml = `
      <a href="/supplierDashboard" class="nav-item">Supplier Dashboard</a>
    `;
    // Show supplier areas of profile menu
    document.getElementById('profile-customer-area').classList.add('hidden');
    document.getElementById('profile-supplier-area').classList.remove('hidden');
  } else if (currentUser.role === 'admin') {
    navHtml = `
      <a href="/adminDashboard" class="nav-item">Admin Dashboard</a>
    `;
    document.getElementById('profile-customer-area').classList.remove('hidden');
    document.getElementById('profile-supplier-area').classList.add('hidden');
  }

  mainNav.innerHTML = navHtml;

  // Setup click interceptors on new nav links
  mainNav.querySelectorAll('.nav-item').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const view = link.getAttribute('href').substring(1);
      navigate(view);
    });
  });

  // Load and subscribe to notifications
  fetchNotifications();
}

// --- API Helpers ---
async function apiFetch(endpoint, options = {}) {
  try {
    const response = await fetch(endpoint, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (response.status === 401) {
      // Session expired or unauthorized
      currentUser = null;
      renderHeader();
      stopPolling();
      navigate('landing');
      return null;
    }

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Something went wrong');
    }
    return data;
  } catch (error) {
    showToast(error.message, 'danger');
    throw error;
  }
}

// --- Toast Notifications ---
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = 'ℹ️';
  if (type === 'success') icon = '✅';
  if (type === 'danger') icon = '❌';
  if (type === 'warning') icon = '⚠️';

  toast.innerHTML = `<span>${icon}</span> <div>${message}</div>`;
  container.appendChild(toast);

  // Automatically remove after 4 seconds
  setTimeout(() => {
    toast.style.animation = 'slide-out 0.25s forwards';
    toast.addEventListener('animationend', () => {
      toast.remove();
    });
  }, 4000);
}

// --- Real-time updates Polling ---
function startPolling() {
  if (pollingIntervalId) clearInterval(pollingIntervalId);
  
  pollingIntervalId = setInterval(() => {
    if (currentUser) {
      fetchNotifications(true); // silent background fetch
      
      // If customer dashboard is currently visible, update stats & active cards
      if (!views.customerDashboard.classList.contains('hidden')) {
        loadCustomerDashboard(true);
      }
      
      // If supplier dashboard is visible, refresh
      if (!views.supplierDashboard.classList.contains('hidden')) {
        loadSupplierDashboard(true);
      }

      // If tracking details are open
      if (!views.trackOrder.classList.contains('hidden') && currentTrackingOrderId) {
        loadOrderTracker(true);
      }
    }
  }, 10000); // Poll every 10 seconds
}

function stopPolling() {
  if (pollingIntervalId) {
    clearInterval(pollingIntervalId);
    pollingIntervalId = null;
  }
}

// --- Fetch Notifications ---
async function fetchNotifications(silent = false) {
  try {
    const response = await fetch('/api/notifications');
    if (response.status === 200) {
      const notifications = await response.json();
      const unread = notifications.filter(n => n.is_read === 0);
      const badge = document.getElementById('bell-badge');

      if (unread.length > 0) {
        badge.textContent = unread.length;
        badge.classList.remove('hidden');
        if (!silent) {
          // Toast the latest one
          const latest = unread[0];
          showToast(latest.message, 'info');
        }
      } else {
        badge.classList.add('hidden');
      }

      // Render Dropdown List
      const listContainer = document.getElementById('notifications-list');
      if (notifications.length === 0) {
        listContainer.innerHTML = '<p class="empty-state">No new notifications</p>';
      } else {
        listContainer.innerHTML = notifications.map(n => `
          <div class="notification-item ${n.is_read === 0 ? 'unread' : ''}">
            <p>${n.message}</p>
            <span class="text-muted text-xs">${new Date(n.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
          </div>
        `).join('');
      }
    }
  } catch (e) {
    console.error('Error fetching notifications:', e);
  }
}

// --- Customer Dashboard logic ---
async function loadCustomerDashboard(silent = false) {
  if (!silent && !currentUser) return;

  try {
    const orders = await apiFetch('/api/orders');
    if (!orders) return;
    ordersCache = orders;

    const activeOrders = orders.filter(o => ['Pending', 'Accepted', 'Preparing', 'Out for Delivery'].includes(o.status));
    const completedOrders = orders.filter(o => o.status === 'Delivered');
    
    // Stats Outflow Calculation
    const totalSpent = completedOrders.reduce((sum, o) => sum + o.total_price, 0);

    document.getElementById('cust-active-count').textContent = activeOrders.length;
    document.getElementById('cust-completed-count').textContent = completedOrders.length;
    document.getElementById('cust-spent-amount').textContent = `${totalSpent.toLocaleString()} PKR`;

    // Welcome user greeting
    document.getElementById('cust-welcome-title').textContent = `Assalam-o-Alaikum, ${currentUser.name}!`;

    // Render Active Deliveries
    const activeGrid = document.getElementById('cust-active-orders');
    if (activeOrders.length === 0) {
      activeGrid.innerHTML = '<p class="empty-state">No active deliveries. Place a new order above.</p>';
    } else {
      activeGrid.innerHTML = activeOrders.map(o => {
        let btnText = o.status === 'Pending' ? 'Cancel Request' : 'Track Shipment';
        let badgeClass = 'badge-pending';
        if (o.status === 'Accepted') badgeClass = 'badge-preparing';
        if (o.status === 'Preparing') badgeClass = 'badge-preparing';
        if (o.status === 'Out for Delivery') badgeClass = 'badge-transit';

        return `
          <div class="active-card">
            <div class="active-header">
              <h4>Order #${o.id}</h4>
              <span class="badge ${badgeClass}">${o.status}</span>
            </div>
            <p><strong>Product:</strong> ${o.product_name} (${o.product_capacity}L)</p>
            <p><strong>Quantity:</strong> ${o.quantity} units</p>
            <p><strong>Supplier:</strong> ${o.supplier_name}</p>
            <p><strong>Delivery:</strong> ${o.delivery_date} | ${o.delivery_time}</p>
            <div class="active-footer">
              <button class="btn btn-primary btn-sm track-btn" data-id="${o.id}">${btnText}</button>
            </div>
          </div>
        `;
      }).join('');

      // Add click listeners to track buttons
      activeGrid.querySelectorAll('.track-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const orderId = parseInt(btn.getAttribute('data-id'));
          navigate('trackOrder', { orderId });
        });
      });
    }

    // Render Recent Orders Table
    const tableBody = document.getElementById('cust-recent-orders-rows');
    const recent = orders.slice(0, 5); // Show top 5
    if (recent.length === 0) {
      tableBody.innerHTML = '<tr><td colspan="8" class="empty-state">No order history available.</td></tr>';
    } else {
      tableBody.innerHTML = recent.map(o => `
        <tr>
          <td>#${o.id}</td>
          <td>${o.supplier_name}</td>
          <td>${o.product_name}</td>
          <td>${o.quantity}</td>
          <td><strong>${o.total_price} PKR</strong></td>
          <td>${o.delivery_date}</td>
          <td><span class="badge ${o.status === 'Delivered' ? 'badge-delivered' : o.status === 'Cancelled' ? 'badge-cancelled' : 'badge-preparing'}">${o.status}</span></td>
          <td>
            <button class="btn btn-secondary btn-sm table-track-btn" data-id="${o.id}">Details</button>
          </td>
        </tr>
      `).join('');

      tableBody.querySelectorAll('.table-track-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const orderId = parseInt(btn.getAttribute('data-id'));
          navigate('trackOrder', { orderId });
        });
      });
    }

  } catch (error) {
    console.error('Error loading dashboard:', error);
  }
}

// --- Booking wizard (New Order page) ---
let selectedProduct = null;

async function loadBookingWizard() {
  selectedProduct = null;
  document.getElementById('wizard-step-1').classList.remove('hidden');
  document.getElementById('wizard-step-2').classList.add('hidden');
  
  try {
    const products = await apiFetch('/api/products');
    if (!products) return;
    productsCache = products;
    renderBookingProducts(products);
  } catch (e) {
    console.error(e);
  }
}

function renderBookingProducts(products) {
  const grid = document.getElementById('booking-products-grid');
  if (products.length === 0) {
    grid.innerHTML = '<p class="empty-state">No water products are currently available in your area.</p>';
    return;
  }

  grid.innerHTML = products.map(p => {
    let icon = '🍼';
    let typeName = 'Filtered Can';
    if (p.type === 'mineral_can') {
      icon = '💎';
      typeName = 'Mineral Water Can';
    } else if (p.type === 'tanker') {
      icon = '🚛';
      typeName = 'Water Tanker';
    }

    return `
      <div class="product-card">
        <div class="product-card-icon">${icon}</div>
        <h4>${p.name}</h4>
        <span class="badge badge-preparing mb-4">${typeName} (${p.capacity_liters}L)</span>
        <p class="product-card-supplier">Retailer: <strong>${p.supplier_name}</strong> (${p.supplier_rating}★)</p>
        <p class="text-sm text-muted mb-4">Located at: ${p.supplier_address}</p>
        <div class="product-card-price">${p.price} PKR</div>
        <button class="btn btn-primary btn-block select-product-btn" data-id="${p.id}">Select Product</button>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('.select-product-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const prodId = parseInt(btn.getAttribute('data-id'));
      const product = productsCache.find(p => p.id === prodId);
      if (product) {
        selectProductForBooking(product);
      }
    });
  });
}

function selectProductForBooking(product) {
  selectedProduct = product;
  
  // Render Summary Card
  const summary = document.getElementById('selected-product-card');
  let icon = product.type === 'tanker' ? '🚛' : '🍼';
  summary.innerHTML = `
    <div>
      <h3>${icon} ${product.name}</h3>
      <p class="text-muted">Supplier: ${product.supplier_name} | Price: ${product.price} PKR per unit</p>
    </div>
    <div style="font-weight: 800; font-size: 1.15rem; color: var(--primary-color)">
      ${product.price} PKR
    </div>
  `;

  // Prepopulate default fields
  document.getElementById('order-quantity').value = 1;
  document.getElementById('calc-total-pkr').textContent = `${product.price} PKR`;
  document.getElementById('order-address').value = currentUser.address || '';
  
  // Set date input min as today
  const today = new Date().toISOString().split('T')[0];
  const dateInput = document.getElementById('order-date');
  dateInput.value = today;
  dateInput.min = today;

  // Toggle wizard steps
  document.getElementById('wizard-step-1').classList.add('hidden');
  document.getElementById('wizard-step-2').classList.remove('hidden');
}

// Calculate total pricing dynamically
document.getElementById('order-quantity').addEventListener('input', (e) => {
  if (selectedProduct) {
    const qty = parseInt(e.target.value) || 1;
    const total = selectedProduct.price * qty;
    document.getElementById('calc-total-pkr').textContent = `${total.toLocaleString()} PKR`;
  }
});

// Submit water booking
document.getElementById('order-booking-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!selectedProduct) return;

  const quantity = parseInt(document.getElementById('order-quantity').value);
  const address = document.getElementById('order-address').value;
  const delivery_date = document.getElementById('order-date').value;
  const delivery_time = document.getElementById('order-time').value;
  const payment_method = document.getElementById('order-payment').value;

  try {
    const result = await apiFetch('/api/orders', {
      method: 'POST',
      body: JSON.stringify({
        product_id: selectedProduct.id,
        quantity,
        address,
        delivery_date,
        delivery_time,
        payment_method
      })
    });

    if (result && result.success) {
      showToast('Water order submitted successfully!', 'success');
      navigate('customerDashboard');
    }
  } catch (err) {
    console.error(err);
  }
});

document.getElementById('booking-back-btn').addEventListener('click', () => {
  document.getElementById('wizard-step-2').classList.add('hidden');
  document.getElementById('wizard-step-1').classList.remove('hidden');
});

// --- Order tracking logic ---
async function loadOrderTracker(silent = false) {
  if (!currentTrackingOrderId) {
    navigate('customerDashboard');
    return;
  }

  try {
    // We can filter from cached orders or fetch fresh details
    const orders = await apiFetch('/api/orders');
    if (!orders) return;
    
    const order = orders.find(o => o.id === currentTrackingOrderId);
    if (!order) {
      showToast('Order not found', 'danger');
      navigate('customerDashboard');
      return;
    }

    // Populate header info
    document.getElementById('track-order-id').textContent = order.id;
    const badge = document.getElementById('track-order-badge');
    badge.textContent = order.status;
    badge.className = `badge badge-${order.status === 'Pending' ? 'pending' : order.status === 'Delivered' ? 'delivered' : order.status === 'Cancelled' ? 'cancelled' : 'preparing'}`;

    // Populate summary rows
    document.getElementById('track-prod-name').textContent = order.product_name;
    document.getElementById('track-qty').textContent = `${order.quantity} units (${order.product_capacity}L)`;
    document.getElementById('track-price').textContent = `${order.total_price.toLocaleString()} PKR`;
    document.getElementById('track-time').textContent = `${order.delivery_date} | ${order.delivery_time}`;
    document.getElementById('track-shipping-address').textContent = order.address;

    // Stepper updates
    const statuses = ['Pending', 'Accepted', 'Preparing', 'Out for Delivery', 'Delivered'];
    const currentIdx = statuses.indexOf(order.status);

    statuses.forEach((status, idx) => {
      const slug = status.toLowerCase().replace(/ /g, '-');
      const node = document.getElementById(`step-node-${slug}`);
      if (!node) return;

      node.classList.remove('completed', 'active');
      
      if (idx < currentIdx) {
        node.classList.add('completed');
      } else if (idx === currentIdx) {
        node.classList.add('active');
      }

      // Connect lines
      if (idx > 0) {
        const line = document.getElementById(`step-line-${idx}`);
        if (line) {
          if (idx <= currentIdx) {
            line.classList.add('active');
          } else {
            line.classList.remove('active');
          }
        }
      }
    });

    // Populate Courier Driver Details
    document.getElementById('track-supplier-name').textContent = order.supplier_name;
    document.getElementById('track-supplier-phone').textContent = order.supplier_phone;
    document.getElementById('track-driver-name').textContent = order.delivery_person_name || 'Assigning soon...';
    document.getElementById('track-driver-phone').textContent = order.delivery_person_phone || '-';

    // WhatsApp Contact URL setup (Pakistani phone helper)
    const waPhone = order.supplier_phone.replace(/[^0-9]/g, '');
    const waUrl = `https://wa.me/${waPhone}?text=Salam,%20I%20am%20inquiring%20about%20my%20water%20order%20%23${order.id}`;
    document.getElementById('contact-retailer-whatsapp').setAttribute('href', waUrl);

    // Map Animation toggle
    const driverMarker = document.getElementById('sim-driver');
    if (order.status === 'Out for Delivery') {
      driverMarker.classList.add('animate-driver');
      driverMarker.classList.remove('hidden');
    } else if (order.status === 'Delivered') {
      driverMarker.classList.remove('animate-driver');
      // Position driver at customer house (bottom-right)
      driverMarker.style.top = '75%';
      driverMarker.style.left = '75%';
      driverMarker.classList.remove('hidden');
    } else {
      driverMarker.classList.remove('animate-driver');
      driverMarker.classList.add('hidden'); // Driver not dispatched yet
    }

  } catch (e) {
    console.error(e);
  }
}

document.getElementById('track-back-dash-btn').addEventListener('click', () => {
  navigate(currentUser.role === 'supplier' ? 'supplierDashboard' : 'customerDashboard');
});

// --- Order history logs view ---
async function loadOrderHistory() {
  try {
    const orders = await apiFetch('/api/orders');
    if (!orders) return;
    ordersCache = orders;
    applyHistoryFilters();
  } catch (e) {
    console.error(e);
  }
}

function applyHistoryFilters() {
  const searchQuery = document.getElementById('history-search').value.toLowerCase();
  const statusFilter = document.getElementById('history-status-select').value;
  const typeFilter = document.getElementById('history-type-select').value;

  const filtered = ordersCache.filter(o => {
    const matchesSearch = o.supplier_name.toLowerCase().includes(searchQuery) || o.address.toLowerCase().includes(searchQuery);
    const matchesStatus = statusFilter === 'ALL' || o.status === statusFilter;
    const matchesType = typeFilter === 'ALL' || o.product_type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  const tbody = document.getElementById('history-table-rows');
  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="10" class="empty-state">No water delivery logs match your filter criteria.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map(o => `
    <tr>
      <td>#${o.id}</td>
      <td><strong>${o.supplier_name || o.customer_name}</strong></td>
      <td>${o.product_name} (${o.product_capacity}L)</td>
      <td><span class="badge badge-preparing">${o.product_type === 'mineral_can' ? 'Mineral Can' : o.product_type === 'can' ? 'Can' : 'Tanker'}</span></td>
      <td>${o.quantity}</td>
      <td><strong>${o.total_price} PKR</strong></td>
      <td>${o.delivery_date}<br><small>${o.delivery_time}</small></td>
      <td><span class="badge ${o.status === 'Delivered' ? 'badge-delivered' : o.status === 'Cancelled' ? 'badge-cancelled' : o.status === 'Pending' ? 'badge-pending' : 'badge-preparing'}">${o.status}</span></td>
      <td><span class="badge ${o.payment_status === 'Completed' ? 'badge-delivered' : 'badge-pending'}">${o.payment_status}</span></td>
      <td>
        <button class="btn btn-secondary btn-sm view-track-details-btn" data-id="${o.id}">Details</button>
      </td>
    </tr>
  `).join('');

  tbody.querySelectorAll('.view-track-details-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const orderId = parseInt(btn.getAttribute('data-id'));
      navigate('trackOrder', { orderId });
    });
  });
}

document.getElementById('history-search').addEventListener('input', applyHistoryFilters);
document.getElementById('history-status-select').addEventListener('change', applyHistoryFilters);
document.getElementById('history-type-select').addEventListener('change', applyHistoryFilters);
document.getElementById('history-new-order-btn').addEventListener('click', () => navigate('newOrder'));

// --- Supplier Dashboard Logic ---
let activeSupplierTab = 'orders';

async function loadSupplierDashboard(silent = false) {
  if (!silent && !currentUser) return;

  try {
    const orders = await apiFetch('/api/orders');
    if (!orders) return;

    const pending = orders.filter(o => o.status === 'Pending');
    const active = orders.filter(o => ['Accepted', 'Preparing', 'Out for Delivery'].includes(o.status));
    const completed = orders.filter(o => o.status === 'Delivered');

    const totalSales = completed.reduce((sum, o) => sum + o.total_price, 0);

    // Update Header Brand Cards
    document.getElementById('supplier-title-name').textContent = currentUser.name + ' | ' + (currentUser.company_name || 'Water Hub');
    document.getElementById('supplier-title-address').textContent = currentUser.address;
    
    document.getElementById('sup-stat-sales').textContent = `${totalSales.toLocaleString()} PKR`;
    document.getElementById('sup-stat-pending').textContent = pending.length;
    document.getElementById('sup-stat-delivered').textContent = completed.length;

    // Render Pending Queue Cards
    const queue = document.getElementById('sup-pending-queue');
    if (pending.length === 0) {
      queue.innerHTML = '<p class="empty-state">No pending water booking requests.</p>';
    } else {
      queue.innerHTML = pending.map(o => `
        <div class="queue-card">
          <div class="active-header">
            <h4>Request #${o.id}</h4>
            <span class="badge badge-pending">PENDING</span>
          </div>
          <p><strong>Customer:</strong> ${o.customer_name}</p>
          <p><strong>Dropoff:</strong> ${o.address}</p>
          <p><strong>Product:</strong> ${o.product_name} (${o.product_capacity}L)</p>
          <p><strong>Quantity:</strong> ${o.quantity} units</p>
          <p><strong>Value:</strong> ${o.total_price} PKR</p>
          <p><strong>Schedule:</strong> ${o.delivery_date} | ${o.delivery_time}</p>
          <div class="queue-card-actions">
            <button class="btn btn-success btn-sm accept-order-btn" data-id="${o.id}">Accept</button>
            <button class="btn btn-secondary btn-sm reject-order-btn" data-id="${o.id}">Reject</button>
          </div>
        </div>
      `).join('');

      // Attach accept/reject event triggers
      queue.querySelectorAll('.accept-order-btn').forEach(btn => {
        btn.addEventListener('click', () => updateOrderStatus(parseInt(btn.getAttribute('data-id')), 'Accepted'));
      });
      queue.querySelectorAll('.reject-order-btn').forEach(btn => {
        btn.addEventListener('click', () => updateOrderStatus(parseInt(btn.getAttribute('data-id')), 'Cancelled'));
      });
    }

    // Render Active Shipments Table
    const activeTbody = document.getElementById('sup-active-orders-rows');
    if (active.length === 0) {
      activeTbody.innerHTML = '<tr><td colspan="9" class="empty-state">No active shipments in transit.</td></tr>';
    } else {
      activeTbody.innerHTML = active.map(o => {
        let statusOptions = '';
        if (o.status === 'Accepted') {
          statusOptions = `
            <option value="Accepted" selected>Accepted</option>
            <option value="Preparing">Start Preparing</option>
            <option value="Cancelled">Cancel Shipment</option>
          `;
        } else if (o.status === 'Preparing') {
          statusOptions = `
            <option value="Preparing" selected>Preparing</option>
            <option value="Out for Delivery">Dispatch/Out for Delivery</option>
            <option value="Cancelled">Cancel Shipment</option>
          `;
        } else if (o.status === 'Out for Delivery') {
          statusOptions = `
            <option value="Out for Delivery" selected>Out for Delivery</option>
            <option value="Delivered">Mark Delivered</option>
            <option value="Cancelled">Cancel Shipment</option>
          `;
        }

        return `
          <tr>
            <td>#${o.id}</td>
            <td><strong>${o.customer_name}</strong></td>
            <td>${o.customer_phone || '-'}</td>
            <td>${o.product_name}</td>
            <td>${o.quantity}</td>
            <td>${o.delivery_date}<br><small>${o.delivery_time}</small></td>
            <td><span class="badge badge-preparing">${o.status}</span></td>
            <td>
              <select class="form-control status-select" data-id="${o.id}">
                ${statusOptions}
              </select>
            </td>
            <td>
              <small>Driver: ${o.delivery_person_name || 'N/A'}</small><br>
              <small>Phone: ${o.delivery_person_phone || 'N/A'}</small>
            </td>
          </tr>
        `;
      }).join('');

      // Status dropdown change triggers
      activeTbody.querySelectorAll('.status-select').forEach(select => {
        select.addEventListener('change', (e) => {
          const orderId = parseInt(select.getAttribute('data-id'));
          const nextStatus = e.target.value;
          
          if (nextStatus === 'Out for Delivery') {
            // Open dispatch courier modal
            document.getElementById('dispatch-modal-order-id').value = orderId;
            document.getElementById('dispatch-driver-name').value = '';
            document.getElementById('dispatch-driver-phone').value = '';
            document.getElementById('dispatch-time').value = 'Within 45 minutes';
            document.getElementById('dispatch-modal').classList.remove('hidden');
          } else {
            updateOrderStatus(orderId, nextStatus);
          }
        });
      });
    }

    // Load supplier inventory items
    if (activeSupplierTab === 'inventory') {
      loadSupplierInventory();
    }

  } catch (e) {
    console.error(e);
  }
}

async function updateOrderStatus(orderId, status, extra = {}) {
  try {
    const result = await apiFetch(`/api/orders/${orderId}/status`, {
      method: 'POST',
      body: JSON.stringify({
        status,
        ...extra
      })
    });
    if (result && result.success) {
      showToast(`Order #${orderId} updated to ${status}`, 'success');
      loadSupplierDashboard();
    }
  } catch (e) {
    console.error(e);
  }
}

// Supplier logistics dispatch modal submit
document.getElementById('dispatch-modal-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const orderId = parseInt(document.getElementById('dispatch-modal-order-id').value);
  const driverName = document.getElementById('dispatch-driver-name').value;
  const driverPhone = document.getElementById('dispatch-driver-phone').value;
  const eta = document.getElementById('dispatch-time').value;

  document.getElementById('dispatch-modal').classList.add('hidden');

  await updateOrderStatus(orderId, 'Out for Delivery', {
    delivery_person_name: driverName,
    delivery_person_phone: driverPhone,
    estimated_delivery_time: eta
  });
});

document.getElementById('dispatch-modal-close-btn').addEventListener('click', () => {
  document.getElementById('dispatch-modal').classList.add('hidden');
  loadSupplierDashboard(); // reload to reset dropdown state
});

// Tab navigation for supplier dashboard
document.getElementById('sup-tab-orders').addEventListener('click', (e) => {
  activeSupplierTab = 'orders';
  document.getElementById('sup-tab-orders').classList.add('active');
  document.getElementById('sup-tab-inventory').classList.remove('active');
  document.getElementById('sup-orders-section').classList.remove('hidden');
  document.getElementById('sup-inventory-section').classList.add('hidden');
});

document.getElementById('sup-tab-inventory').addEventListener('click', (e) => {
  activeSupplierTab = 'inventory';
  document.getElementById('sup-tab-orders').classList.remove('active');
  document.getElementById('sup-tab-inventory').classList.add('active');
  document.getElementById('sup-orders-section').classList.add('hidden');
  document.getElementById('sup-inventory-section').classList.remove('hidden');
  loadSupplierInventory();
});

// --- Supplier Inventory catalog CRUD ---
async function loadSupplierInventory() {
  try {
    const products = await apiFetch('/api/products');
    if (!products) return;

    const tbody = document.getElementById('sup-product-rows');
    if (products.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No products registered. Add one below.</td></tr>';
      return;
    }

    tbody.innerHTML = products.map(p => `
      <tr>
        <td><strong>${p.name}</strong></td>
        <td>${p.type === 'mineral_can' ? 'Mineral Can' : p.type === 'can' ? 'Can' : 'Tanker'}</td>
        <td>${p.capacity_liters} Liters</td>
        <td><strong>${p.price} PKR</strong></td>
        <td>
          <span class="badge ${p.stock_status === 'in_stock' ? 'badge-delivered' : 'badge-cancelled'}">
            ${p.stock_status === 'in_stock' ? 'In Stock' : 'Out of Stock'}
          </span>
        </td>
        <td>
          <button class="btn btn-secondary btn-sm edit-prod-btn" data-id="${p.id}">Edit</button>
          <button class="btn btn-secondary btn-sm toggle-stock-btn" data-id="${p.id}">${p.stock_status === 'in_stock' ? 'Set Out of Stock' : 'Set In Stock'}</button>
          <button class="btn btn-secondary btn-sm text-danger delete-prod-btn" data-id="${p.id}">Delete</button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.edit-prod-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const prodId = parseInt(btn.getAttribute('data-id'));
        const product = products.find(p => p.id === prodId);
        openProductModal(product);
      });
    });

    tbody.querySelectorAll('.toggle-stock-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const prodId = parseInt(btn.getAttribute('data-id'));
        const product = products.find(p => p.id === prodId);
        const nextStock = product.stock_status === 'in_stock' ? 'out_of_stock' : 'in_stock';
        
        await apiFetch(`/api/products/${prodId}`, {
          method: 'PUT',
          body: JSON.stringify({ stock_status: nextStock })
        });
        showToast('Stock status updated', 'success');
        loadSupplierInventory();
      });
    });

    tbody.querySelectorAll('.delete-prod-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (confirm('Are you sure you want to delete this water product?')) {
          const prodId = parseInt(btn.getAttribute('data-id'));
          await apiFetch(`/api/products/${prodId}`, { method: 'DELETE' });
          showToast('Product removed', 'success');
          loadSupplierInventory();
        }
      });
    });

  } catch (e) {
    console.error(e);
  }
}

// Product catalog modal controllers
function openProductModal(product = null) {
  const modal = document.getElementById('product-modal');
  const title = document.getElementById('product-modal-title');
  const form = document.getElementById('product-modal-form');

  if (product) {
    title.textContent = 'Edit Water Product';
    document.getElementById('product-modal-id').value = product.id;
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-type').value = product.type;
    document.getElementById('product-capacity').value = product.capacity_liters;
    document.getElementById('product-price').value = product.price;
    document.getElementById('product-stock').value = product.stock_status;
  } else {
    title.textContent = 'Add Water Product';
    form.reset();
    document.getElementById('product-modal-id').value = '';
  }

  modal.classList.remove('hidden');
}

document.getElementById('sup-add-product-btn').addEventListener('click', () => openProductModal());
document.getElementById('product-modal-close-btn').addEventListener('click', () => {
  document.getElementById('product-modal').classList.add('hidden');
});

document.getElementById('product-modal-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('product-modal-id').value;
  const name = document.getElementById('product-name').value;
  const type = document.getElementById('product-type').value;
  const capacity_liters = document.getElementById('product-capacity').value;
  const price = document.getElementById('product-price').value;
  const stock_status = document.getElementById('product-stock').value;

  const payload = { name, type, capacity_liters, price, stock_status };

  try {
    let response;
    if (id) {
      // Edit
      response = await apiFetch(`/api/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } else {
      // Add
      response = await apiFetch('/api/products', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    }

    if (response && response.success) {
      showToast('Water catalog product saved!', 'success');
      document.getElementById('product-modal').classList.add('hidden');
      loadSupplierInventory();
    }
  } catch (err) {
    console.error(err);
  }
});


// --- Admin Dashboard Logic ---
let activeAdminTab = 'accounts';

async function loadAdminDashboard() {
  try {
    const analytics = await apiFetch('/api/admin/analytics');
    if (!analytics) return;

    // Set stats
    document.getElementById('admin-stat-users').textContent = analytics.totalUsers;
    document.getElementById('admin-stat-suppliers').textContent = analytics.totalSuppliers;
    document.getElementById('admin-stat-orders').textContent = analytics.totalOrders;
    document.getElementById('admin-stat-revenue').textContent = `${analytics.totalRevenue.toLocaleString()} PKR`;

    if (activeAdminTab === 'accounts') {
      loadAdminAccounts();
    } else {
      loadAdminOrders();
    }
  } catch (e) {
    console.error(e);
  }
}

async function loadAdminAccounts() {
  try {
    const users = await apiFetch('/api/admin/users');
    if (!users) return;

    const tbody = document.getElementById('admin-user-rows');
    tbody.innerHTML = users.map(u => `
      <tr>
        <td>#${u.id}</td>
        <td><strong>${u.name}</strong></td>
        <td>${u.email}</td>
        <td><span class="badge ${u.role === 'supplier' ? 'badge-preparing' : 'badge-pending'}">${u.role === 'supplier' ? 'Supplier' : 'Customer'}</span></td>
        <td>${u.company_name || '-'}</td>
        <td>${u.default_phone || u.supplier_phone || '-'}</td>
        <td>${new Date(u.created_at).toLocaleDateString()}</td>
        <td>
          <span class="badge ${u.status === 'active' ? 'badge-delivered' : 'badge-cancelled'}">
            ${u.status.toUpperCase()}
          </span>
        </td>
        <td>
          <button class="btn btn-secondary btn-sm toggle-status-btn" data-id="${u.id}">
            ${u.status === 'active' ? '🔑 Suspend' : '✅ Activate'}
          </button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.toggle-status-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const userId = parseInt(btn.getAttribute('data-id'));
        const res = await apiFetch(`/api/admin/users/${userId}/status`, { method: 'POST' });
        if (res && res.success) {
          showToast(`Account status updated to ${res.status}`, 'success');
          loadAdminDashboard();
        }
      });
    });

  } catch (e) {
    console.error(e);
  }
}

async function loadAdminOrders() {
  try {
    const orders = await apiFetch('/api/orders');
    if (!orders) return;

    const tbody = document.getElementById('admin-orders-rows');
    tbody.innerHTML = orders.map(o => `
      <tr>
        <td>#${o.id}</td>
        <td><strong>${o.customer_name}</strong><br><small>${o.customer_phone || '-'}</small></td>
        <td>${o.supplier_name}</td>
        <td>${o.product_name}</td>
        <td>${o.quantity}</td>
        <td><strong>${o.total_price} PKR</strong></td>
        <td>${o.delivery_date}<br><small>${o.delivery_time}</small></td>
        <td><span class="badge ${o.status === 'Delivered' ? 'badge-delivered' : o.status === 'Cancelled' ? 'badge-cancelled' : 'badge-preparing'}">${o.status}</span></td>
        <td><span class="badge ${o.payment_status === 'Completed' ? 'badge-delivered' : 'badge-pending'}">${o.payment_status}</span></td>
      </tr>
    `).join('');

  } catch (e) {
    console.error(e);
  }
}

document.getElementById('admin-tab-accounts-btn').addEventListener('click', () => {
  activeAdminTab = 'accounts';
  document.getElementById('admin-tab-accounts-btn').classList.add('active');
  document.getElementById('admin-tab-orders-btn').classList.remove('active');
  document.getElementById('admin-accounts-section').classList.remove('hidden');
  document.getElementById('admin-orders-section').classList.add('hidden');
  loadAdminAccounts();
});

document.getElementById('admin-tab-orders-btn').addEventListener('click', () => {
  activeAdminTab = 'orders';
  document.getElementById('admin-tab-accounts-btn').classList.remove('active');
  document.getElementById('admin-tab-orders-btn').classList.add('active');
  document.getElementById('admin-accounts-section').classList.add('hidden');
  document.getElementById('admin-orders-section').classList.remove('hidden');
  loadAdminOrders();
});


// --- Profile Settings ---
function loadProfileSettings() {
  if (!currentUser) return;

  document.getElementById('profile-name').value = currentUser.name;
  document.getElementById('profile-email').value = currentUser.email;
  document.getElementById('profile-password').value = '';

  if (currentUser.role === 'supplier') {
    document.getElementById('profile-company').value = currentUser.company_name || '';
    document.getElementById('profile-biz-phone').value = currentUser.phone || '';
    document.getElementById('profile-biz-address').value = currentUser.address || '';
  } else {
    document.getElementById('profile-phone').value = currentUser.phone || '';
    document.getElementById('profile-address').value = currentUser.address || '';
  }
}

document.getElementById('profile-settings-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const name = document.getElementById('profile-name').value;
  const password = document.getElementById('profile-password').value;

  let payload = { name };
  if (password) payload.password = password;

  if (currentUser.role === 'supplier') {
    payload.company_name = document.getElementById('profile-company').value;
    payload.phone = document.getElementById('profile-biz-phone').value;
    payload.address = document.getElementById('profile-biz-address').value;
  } else {
    payload.phone = document.getElementById('profile-phone').value;
    payload.address = document.getElementById('profile-address').value;
  }

  try {
    const result = await apiFetch('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });

    if (result && result.success) {
      currentUser = result.user;
      showToast('Profile configuration saved!', 'success');
      renderHeader();
    }
  } catch (err) {
    console.error(err);
  }
});


// --- Authentication form handlers ---

// Login
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  try {
    const result = await apiFetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });

    if (result && result.success) {
      currentUser = result.user;
      showToast(`Welcome back, ${currentUser.name}!`, 'success');
      renderHeader();
      startPolling();

      // Redirect to correct dashboard
      if (currentUser.role === 'customer') {
        navigate('customerDashboard');
      } else if (currentUser.role === 'supplier') {
        navigate('supplierDashboard');
      } else if (currentUser.role === 'admin') {
        navigate('adminDashboard');
      }
    }
  } catch (e) {
    console.error(e);
  }
});

// Register Toggle
let activeRegisterRole = 'customer';

document.getElementById('tab-cust-role').addEventListener('click', () => {
  activeRegisterRole = 'customer';
  document.getElementById('tab-cust-role').classList.add('active');
  document.getElementById('tab-supp-role').classList.remove('active');
  document.getElementById('supplier-fields').classList.add('hidden');
  document.getElementById('reg-phone-group').classList.remove('hidden');
  document.getElementById('reg-address-group').classList.remove('hidden');
});

document.getElementById('tab-supp-role').addEventListener('click', () => {
  activeRegisterRole = 'supplier';
  document.getElementById('tab-cust-role').classList.remove('active');
  document.getElementById('tab-supp-role').classList.add('active');
  document.getElementById('supplier-fields').classList.remove('hidden');
  document.getElementById('reg-phone-group').classList.add('hidden');
  document.getElementById('reg-address-group').classList.add('hidden');
});

// Register submit
document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('register-name').value;
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;

  let payload = {
    name,
    email,
    password,
    role: activeRegisterRole
  };

  if (activeRegisterRole === 'supplier') {
    payload.company_name = document.getElementById('register-company').value;
    payload.phone = document.getElementById('register-business-phone').value;
    payload.address = document.getElementById('register-business-address').value;
  } else {
    payload.phone = document.getElementById('register-phone').value;
    payload.address = document.getElementById('register-address').value;
  }

  try {
    const result = await apiFetch('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    if (result && result.success) {
      currentUser = result.user;
      showToast('Registration complete! Welcome to AquaConnect.', 'success');
      renderHeader();
      startPolling();

      if (currentUser.role === 'customer') {
        navigate('customerDashboard');
      } else {
        navigate('supplierDashboard');
      }
    }
  } catch (err) {
    console.error(err);
  }
});


// Logout Action
document.getElementById('logout-btn').addEventListener('click', async () => {
  try {
    await fetch('/api/auth/logout', { method: 'POST' });
    currentUser = null;
    renderHeader();
    stopPolling();
    showToast('Logged out successfully', 'success');
    navigate('landing');
  } catch (e) {
    console.error(e);
  }
});

// --- General Navigation button clicks ---
document.getElementById('logo-btn').addEventListener('click', () => {
  if (currentUser) {
    if (currentUser.role === 'customer') navigate('customerDashboard');
    else if (currentUser.role === 'supplier') navigate('supplierDashboard');
    else navigate('adminDashboard');
  } else {
    navigate('landing');
  }
});

document.getElementById('landing-order-btn').addEventListener('click', () => {
  if (currentUser) navigate('newOrder');
  else navigate('login');
});

document.getElementById('landing-login-btn').addEventListener('click', () => {
  navigate('login');
});

document.getElementById('quick-order-btn').addEventListener('click', () => navigate('newOrder'));
document.getElementById('side-book-btn').addEventListener('click', () => navigate('newOrder'));

document.getElementById('side-dash-link').addEventListener('click', () => navigate('customerDashboard'));
document.getElementById('side-history-link').addEventListener('click', () => navigate('orderHistory'));
document.getElementById('side-profile-link').addEventListener('click', () => navigate('profileSettings'));
document.getElementById('menu-profile-btn').addEventListener('click', (e) => {
  e.preventDefault();
  navigate('profileSettings');
});
document.getElementById('cust-view-all-history').addEventListener('click', () => navigate('orderHistory'));

document.getElementById('go-register-btn').addEventListener('click', () => navigate('register'));
document.getElementById('go-login-btn').addEventListener('click', () => navigate('login'));

// Notifications panel toggler
document.getElementById('bell-btn').addEventListener('click', (e) => {
  e.stopPropagation();
  document.getElementById('notifications-panel').classList.toggle('hidden');
});

document.getElementById('mark-read-btn').addEventListener('click', async (e) => {
  e.stopPropagation();
  try {
    const res = await apiFetch('/api/notifications/read', { method: 'POST' });
    if (res && res.success) {
      document.getElementById('bell-badge').classList.add('hidden');
      document.querySelectorAll('.notification-item').forEach(item => item.classList.remove('unread'));
    }
  } catch (err) {
    console.error(err);
  }
});

// Header user profile dropdown toggle
document.getElementById('user-menu-btn').addEventListener('click', (e) => {
  e.stopPropagation();
  document.getElementById('user-dropdown-panel').classList.toggle('hidden');
});

// Click outside close helpers
window.addEventListener('click', () => {
  document.getElementById('notifications-panel').classList.add('hidden');
  document.getElementById('user-dropdown-panel').classList.add('hidden');
});


// --- Initialization Check on boot ---
async function checkAuthOnBoot() {
  try {
    const res = await fetch('/api/auth/me');
    if (res.status === 200) {
      const data = await res.json();
      currentUser = data.user;
      renderHeader();
      startPolling();
      
      // Navigate to correct dashboard based on session role on boot
      if (currentUser.role === 'customer') {
        navigate('customerDashboard');
      } else if (currentUser.role === 'supplier') {
        navigate('supplierDashboard');
      } else if (currentUser.role === 'admin') {
        navigate('adminDashboard');
      }
    } else {
      navigate('landing');
    }
  } catch (e) {
    navigate('landing');
  }
}

// Boot the client app
checkAuthOnBoot();
