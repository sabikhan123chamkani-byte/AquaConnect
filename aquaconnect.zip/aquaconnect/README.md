# AquaConnect Pakistan

AquaConnect is a full-stack, production-ready MVP web application designed for local water delivery services in Pakistan. It simplifies ordering, tracking, and managing drinking water cans and water tankers.

Built entirely using native Node.js v24 APIs (`http`, `crypto`, `node:sqlite`) with zero external package manager (`npm`) dependencies, ensuring it runs instantly on any machine with `agy-node`.

## Features
- **User Roles**: Separate dashboards and features for Customers, Water Retailers (Suppliers), and System Admins.
- **Customer Booking**: Order drinking water cans (20L), premium mineral cans, or water tankers (5000L/10000L) with drop-off schedules and custom addresses.
- **Logistics Tracking**: Real-time status update pipeline (Pending -> Accepted -> Preparing -> Out for Delivery -> Delivered) with a simulated tracking map.
- **Supplier Catalog Management**: Create, edit, toggle stock, and delete water products.
- **Admin Control Center**: Monitor registered users, manage account locks (Suspended/Active), audit platform orders, and view aggregated earnings in PKR.
- **Real-Time Polling Engine**: Automatically refreshes order updates, shipping states, and notification lists every 10 seconds.

## Database Schema
The database uses a local SQLite file (`aquaconnect.db`) with tables:
- `users`: Credentials, password hash/salt, roles, and status.
- `suppliers`: Business details, brand name, rating, and addresses.
- `products`: Water supply packages, capacity (liters), price, and stock status.
- `orders`: Purchase records connecting customers, suppliers, products, and prices.
- `deliveries`: Courier driver assignment, ETA details, and statuses.
- `payments`: Order invoices with status (Pending/Completed) and transactions.
- `notifications`: Alert logs sent upon dispatch, status changes, and bookings.
- `sessions`: Secure cookies authentication records.

---

## Installation & Running Instructions

Ensure `agy-node` (or `node` version >= 22.5.0) is available on your machine.

### 1. Launch the Server
Navigate to the directory and run:
```powershell
agy-node server.js
```
The server will initialize the SQLite database file, auto-seed realistic Pakistani retail water data (Karachi, Islamabad, Lahore locations, and PKR prices), and start listening on port `3000`.

### 2. View in Browser
Open your browser and navigate to:
```
http://localhost:3000
```

---

## Sample Seeding Credentials
On initial startup, the database is auto-seeded with the following Pakistani testing profiles:

| Account Type | Email | Password | Details |
|---|---|---|---|
| **Admin** | `admin@aquaconnect.com` | `admin123` | Platform analytics and block controls. |
| **Supplier 1** | `supplier1@aquaconnect.com` | `supplier123` | *Pak-Aqua Premium Cans*, DHA Phase 6, Karachi |
| **Supplier 2** | `supplier2@aquaconnect.com` | `supplier123` | *Indus Water Tanker Service*, H-9, Islamabad |
| **Supplier 3** | `supplier3@aquaconnect.com` | `supplier123` | *Lahore Spring Drinking Water*, Gulberg III, Lahore |
| **Customer 1** | `customer1@aquaconnect.com` | `customer123` | *Muhammad Ali*, Sector F-11/1, Islamabad |
| **Customer 2** | `customer2@aquaconnect.com` | `customer123` | *Ayesha Fatima*, Gulshan-e-Iqbal, Karachi |
