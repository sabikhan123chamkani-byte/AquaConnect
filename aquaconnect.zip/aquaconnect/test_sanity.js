const { DatabaseSync } = require('node:sqlite');
const path = require('path');

console.log('--- RUNNING AQUACONNECT SANITY TESTS ---');

try {
  const dbPath = path.join(__dirname, 'aquaconnect.db');
  console.log(`Checking database file at: ${dbPath}`);
  
  const db = new DatabaseSync(dbPath);
  
  // 1. Verify tables
  const tables = ['users', 'suppliers', 'products', 'orders', 'deliveries', 'payments', 'notifications', 'sessions'];
  console.log('\nVerifying database tables exist...');
  for (const table of tables) {
    const check = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`).all(table);
    if (check.length === 0) {
      throw new Error(`Table '${table}' is missing!`);
    }
    console.log(`✔ Table '${table}' exists.`);
  }

  // 2. Verify seeded data counts
  console.log('\nVerifying seeded account records...');
  const userCount = db.prepare('SELECT count(*) as count FROM users').all()[0].count;
  const supplierCount = db.prepare('SELECT count(*) as count FROM suppliers').all()[0].count;
  const productCount = db.prepare('SELECT count(*) as count FROM products').all()[0].count;
  const orderCount = db.prepare('SELECT count(*) as count FROM orders').all()[0].count;

  console.log(`- Users seeded: ${userCount}`);
  console.log(`- Suppliers seeded: ${supplierCount}`);
  console.log(`- Products seeded: ${productCount}`);
  console.log(`- Orders seeded: ${orderCount}`);

  if (userCount < 5 || supplierCount < 3 || productCount < 6 || orderCount < 3) {
    throw new Error('Database seeding is incomplete or failed!');
  }
  console.log('✔ Seeded data record counts match requirements.');

  // 3. Verify Pakistani specific details exist in seeded data
  console.log('\nVerifying Pakistani region configuration...');
  const suppliers = db.prepare('SELECT company_name, phone, address FROM suppliers').all();
  console.log('Seeded Pakistani Suppliers:');
  suppliers.forEach(s => {
    console.log(`  - ${s.company_name} | Phone: ${s.phone} | Address: ${s.address}`);
    if (!s.phone.startsWith('+92')) {
      throw new Error(`Supplier phone '${s.phone}' does not use Pakistani phone code!`);
    }
  });

  const orders = db.prepare('SELECT id, total_price, address FROM orders').all();
  console.log('Seeded Orders:');
  orders.forEach(o => {
    console.log(`  - Order #${o.id} | Total Price: ${o.total_price} PKR | Address: ${o.address}`);
  });
  
  console.log('\n✔ Verification tests passed successfully! The application database and seeds are healthy.');
  process.exit(0);

} catch (error) {
  console.error('\n❌ Sanity test failed:', error.message);
  process.exit(1);
}
